<div class="col-md-12 mt-5 pt-5">
    <div class="error-body text-center">
        <h1 class="error-title text-danger"></h1>
        <h3 class="text-uppercase error-subtitle">NO PRODUCT FOUND !</h3>
        <p class="text-muted mt-4 mb-4">YOU SEEM TO BE TRYING TO FIND HIS WAY HOME</p>
         {{$slot}}
    </div>
</div>