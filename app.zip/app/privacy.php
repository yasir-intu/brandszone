<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class privacy extends Model
{
    //
}
